package com.example.electricitybillestimator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText unitsEditText;
    private EditText rebateEditText;
    private TextView resultTextView;
    private Button calculateButton;
    private Button detailsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        unitsEditText = findViewById(R.id.unitsEditText);
        rebateEditText = findViewById(R.id.rebateEditText);
        resultTextView = findViewById(R.id.resultTextView);
        calculateButton = findViewById(R.id.calculateButton);
        detailsButton = findViewById(R.id.detailsButton);

        calculateButton.setOnClickListener(this);
        detailsButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == calculateButton) {
            calculateBill();
        } else if (v == detailsButton) {
            openDetailsPage();
        }
    }

    private void calculateBill() {
        double unitsUsed = Double.parseDouble(unitsEditText.getText().toString());
        double rebatePercentage = Double.parseDouble(rebateEditText.getText().toString());

        double billAmount = 0.0;

        if (unitsUsed <= 200) {
            billAmount = unitsUsed * 0.218;
        } else if (unitsUsed <= 300) {
            billAmount = 200 * 0.218 + (unitsUsed - 200) * 0.334;
        } else if (unitsUsed <= 600) {
            billAmount = 200 * 0.218 + 100 * 0.334 + (unitsUsed - 300) * 0.516;
        } else if (unitsUsed > 600) {
            billAmount = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (unitsUsed - 600) * 0.546;
        }

        double rebateAmount = billAmount * (rebatePercentage / 100);
        double finalBillAmount = billAmount - rebateAmount;

        resultTextView.setText(String.format("Electricity Bill: RM %.2f", finalBillAmount));
    }

    private void openDetailsPage() {
        Intent intent = new Intent(this, DetailsActivity.class);
        startActivity(intent);
    }
}
